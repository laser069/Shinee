import React from 'react';
import { Check, Edit2, Trash2, Zap } from 'lucide-react';
import type { DashboardItem, Habit } from '../types';

interface Props {
  items: DashboardItem[];
  onToggle: (id: string, dayIdx: number) => void;
  onEdit: (h: Habit) => void;
  onDelete: (id: string) => void;
}

export const WeeklyHabitTracker: React.FC<Props> = ({ items, onToggle, onEdit, onDelete }) => {
  const weekDays = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-[#1e293b]/30 backdrop-blur-sm">
      <table className="w-full text-left">
        <thead>
          <tr className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] border-b border-slate-800">
            <th className="p-5">Activity</th>
            <th className="p-5 text-center">Streak</th>
            {weekDays.map((d, i) => <th key={i} className="p-5 text-center">{d}</th>)}
            <th className="p-5 text-right">Settings</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/50">
          {items.map(({ habit, currentLog }) => (
            <tr key={habit._id} className="group hover:bg-slate-800/20 transition-colors">
              <td className="p-5">
                <div className="flex items-center gap-4">
                  <span className="text-2xl">{habit.icon}</span>
                  <div>
                    <div className="font-bold text-slate-200">{habit.name}</div>
                    <div className="text-[10px] text-slate-500 font-bold uppercase">{habit.frequencyType} • {habit.goalCount}x</div>
                  </div>
                </div>
              </td>
              <td className="p-5 text-center">
                <div className="inline-flex items-center gap-1 px-2 py-1 bg-orange-500/10 text-orange-500 rounded-lg text-xs font-black">
                  <Zap size={12} fill="currentColor" /> {habit.dailyStreak}
                </div>
              </td>
              {[0, 1, 2, 3, 4, 5, 6].map(idx => {
                const dayData = currentLog.days[idx as keyof typeof currentLog.days];
                const isScheduled = habit.frequencyType === 'fixed' ? habit.fixedDays.includes(idx) : true;
                
                return (
                  <td key={idx} className="p-3 text-center">
                    <button
                      disabled={!isScheduled}
                      onClick={() => onToggle(habit._id, idx)}
                      className={`w-7 h-7 rounded-lg border-2 transition-all flex items-center justify-center mx-auto ${
                        dayData?.completed 
                          ? 'bg-indigo-500 border-indigo-400 text-white shadow-lg shadow-indigo-500/30' 
                          : isScheduled ? 'border-slate-700 bg-slate-900/50 hover:border-slate-500' : 'border-transparent opacity-10'
                      }`}
                    >
                      {dayData?.completed && <Check size={14} strokeWidth={4} />}
                    </button>
                  </td>
                );
              })}
              <td className="p-5 text-right">
                <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => onEdit(habit)} className="p-2 hover:text-white text-slate-500"><Edit2 size={14} /></button>
                  <button onClick={() => onDelete(habit._id)} className="p-2 hover:text-red-500 text-slate-500"><Trash2 size={14} /></button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};