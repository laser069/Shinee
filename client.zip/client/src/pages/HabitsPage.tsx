import React, { useEffect, useState } from 'react';
import habitService from '../services/habitService';
import { HabitModal } from '../components/HabitModal';
import { WeeklyHabitTracker } from '../components/WeeklyHabitTracker';
import type { DashboardItem, Habit } from '../types';
import { Plus, Notebook } from 'lucide-react';

const HabitsPage: React.FC = () => {
  const [items, setItems] = useState<DashboardItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ open: boolean; habit?: Habit }>({ open: false });

  useEffect(() => { fetchHabits(); }, []);

  const fetchHabits = async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const data = await habitService.getHabitsDashboard();
      setItems(data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const handleToggle = async (habitId: string, dayIndex: number) => {
    try {
      // Service now accepts these as two arguments
      await habitService.toggleDay(habitId, dayIndex);
      await fetchHabits(true);
    } catch (err) {
      console.error("Toggle failed", err);
    }
  };

  if (loading) return <div className="p-20 text-center text-slate-500">Initializing Tracker...</div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <div className="flex justify-between items-end mb-8 border-b border-slate-800 pb-6">
        <div>
          <h1 className="text-4xl font-black text-white flex items-center gap-3">
            <Notebook className="text-indigo-500" /> TRACKER
          </h1>
          <p className="text-slate-500 mt-1">Weekly discipline overview</p>
        </div>
        <button
          onClick={() => setModal({ open: true })}
          className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-indigo-500/20"
        >
          <Plus size={18} /> Add Habit
        </button>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-20 bg-slate-900/20 border-2 border-dashed border-slate-800 rounded-3xl">
          <p className="text-slate-500">Your routine is empty. Start building today.</p>
        </div>
      ) : (
        <WeeklyHabitTracker
          items={items}
          onToggle={handleToggle}
          onEdit={(h) => setModal({ open: true, habit: h })}
          onDelete={async (id) => { if (confirm('Delete?')) { await habitService.deleteHabit(id); fetchHabits(); } }}
        />
      )}

      {modal.open && (
        <HabitModal
          habit={modal.habit}
          onClose={() => setModal({ open: false })}
          onSuccess={fetchHabits}
        />
      )}
    </div>
  );
};

export default HabitsPage;