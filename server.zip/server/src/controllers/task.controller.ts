import { Response } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
import taskService from '../services/task.service';

export const createTask = async (req: AuthRequest, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    const { boardId, ...taskData } = req.body;
    const userId = req.user.id;

    const task = await taskService.createTask(userId, boardId, taskData);
    res.status(201).json({ success: true, data: task });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getMyTasks = async (req: AuthRequest, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    const { boardId } = req.query;
    
    // If boardId is provided, filter by board, otherwise get all user tasks
    if (boardId && typeof boardId === 'string') {
      const tasks = await taskService.getTasksByBoard(boardId);
      return res.json({ success: true, data: tasks });
    }
    
    const tasks = await taskService.getTasksByUser(req.user.id);
    res.json({ success: true, data: tasks });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateTask = async (req: AuthRequest, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    const taskId = req.params.id as string;
    const task = await taskService.updateTask(taskId, req.user.id, req.body);
    if (!task) return res.status(404).json({ success: false, message: "Task not found" });
    res.json({ success: true, data: task });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const deleteTask = async (req: AuthRequest, res: Response) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    const taskId = req.params.id as string;
    const task = await taskService.deleteTask(taskId, req.user.id);
    if (!task) return res.status(404).json({ success: false, message: "Task not found" });
    res.json({ success: true, message: "Task deleted successfully" });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error.message });
  }
};